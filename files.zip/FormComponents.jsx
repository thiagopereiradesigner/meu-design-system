import React, { useState } from 'react';

// Design Tokens (Portal Empresa)
const tokens = {
  colors: {
    primary: {
      50: '#E6F4ED',
      500: '#04843B',
      600: '#067647',
      700: '#005A1A',
    },
    neutral: {
      0: '#FFFFFF',
      50: '#F9F9F9',
      100: '#F3F3F3',
      200: '#C6C6C6',
      500: '#656976',
      700: '#333333',
    },
    content: {
      primary: '#393939',
      secondary: '#5E5E5E',
      tertiary: '#727272',
    },
    border: {
      primary: '#393939',
      secondary: '#DDDDDD',
    },
    semantic: {
      error: '#DC2626',
      errorLight: '#FEE2E2',
    },
  },
  spacing: {
    xxs: '4px',
    xs: '8px',
    sm: '12px',
    md: '16px',
    lg: '24px',
  },
  borderRadius: {
    xs: '4px',
    sm: '8px',
  },
  typography: {
    fontFamily: 'Inter, sans-serif',
    fontSize: {
      sm: '12px',
      md: '14px',
      lg: '16px',
    },
    fontWeight: {
      regular: 400,
      medium: 500,
      semibold: 600,
    },
    lineHeight: {
      normal: 1.5,
    },
  },
};

// ==================== TEXTAREA COMPONENT ====================
export const Textarea = ({
  label,
  placeholder = '',
  value = '',
  onChange,
  error = '',
  helperText = '',
  disabled = false,
  rows = 4,
  maxLength,
  showCharCount = false,
  resize = 'vertical', // 'vertical', 'horizontal', 'both', 'none'
  required = false,
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [internalValue, setInternalValue] = useState(value);

  const currentValue = value !== undefined ? value : internalValue;
  const hasError = !!error;

  const handleChange = (e) => {
    const newValue = e.target.value;
    if (maxLength && newValue.length > maxLength) return;
    
    if (onChange) {
      onChange(e);
    } else {
      setInternalValue(newValue);
    }
  };

  const containerStyles = {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacing.xs,
    width: '100%',
    fontFamily: tokens.typography.fontFamily,
  };

  const labelStyles = {
    fontSize: tokens.typography.fontSize.md,
    fontWeight: tokens.typography.fontWeight.medium,
    color: disabled ? tokens.colors.content.tertiary : tokens.colors.content.primary,
    lineHeight: tokens.typography.lineHeight.normal,
  };

  const textareaWrapperStyles = {
    position: 'relative',
    width: '100%',
  };

  const textareaStyles = {
    width: '100%',
    padding: tokens.spacing.sm,
    fontSize: tokens.typography.fontSize.md,
    fontFamily: tokens.typography.fontFamily,
    lineHeight: tokens.typography.lineHeight.normal,
    color: disabled ? tokens.colors.content.tertiary : tokens.colors.content.primary,
    backgroundColor: disabled ? tokens.colors.neutral[50] : tokens.colors.neutral[0],
    border: `1px solid ${
      hasError
        ? tokens.colors.semantic.error
        : isFocused
        ? tokens.colors.primary[500]
        : tokens.colors.border.secondary
    }`,
    borderRadius: tokens.borderRadius.sm,
    outline: 'none',
    resize: resize,
    transition: 'border-color 0.15s ease, box-shadow 0.15s ease',
    cursor: disabled ? 'not-allowed' : 'text',
    boxShadow: isFocused && !hasError ? `0 0 0 3px ${tokens.colors.primary[50]}` : 'none',
  };

  const helperTextStyles = {
    fontSize: tokens.typography.fontSize.sm,
    color: hasError ? tokens.colors.semantic.error : tokens.colors.content.secondary,
    lineHeight: tokens.typography.lineHeight.normal,
  };

  const charCountStyles = {
    fontSize: tokens.typography.fontSize.sm,
    color: tokens.colors.content.tertiary,
    textAlign: 'right',
  };

  const bottomRowStyles = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: tokens.spacing.sm,
  };

  return (
    <div style={containerStyles}>
      {label && (
        <label style={labelStyles}>
          {label}
          {required && <span style={{ color: tokens.colors.semantic.error }}> *</span>}
        </label>
      )}
      
      <div style={textareaWrapperStyles}>
        <textarea
          style={textareaStyles}
          placeholder={placeholder}
          value={currentValue}
          onChange={handleChange}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          disabled={disabled}
          rows={rows}
          maxLength={maxLength}
          aria-invalid={hasError}
          aria-describedby={error ? 'error-message' : helperText ? 'helper-text' : undefined}
        />
      </div>

      {(helperText || error || showCharCount) && (
        <div style={bottomRowStyles}>
          <div style={{ flex: 1 }}>
            {error && (
              <p id="error-message" style={helperTextStyles}>
                {error}
              </p>
            )}
            {!error && helperText && (
              <p id="helper-text" style={helperTextStyles}>
                {helperText}
              </p>
            )}
          </div>
          
          {showCharCount && maxLength && (
            <span style={charCountStyles}>
              {currentValue.length}/{maxLength}
            </span>
          )}
        </div>
      )}
    </div>
  );
};

// ==================== CHECKBOX COMPONENT ====================
export const Checkbox = ({
  label,
  checked = false,
  onChange,
  disabled = false,
  indeterminate = false,
  error = '',
  helperText = '',
}) => {
  const [internalChecked, setInternalChecked] = useState(checked);
  
  const isChecked = checked !== undefined ? checked : internalChecked;
  const hasError = !!error;

  const handleChange = (e) => {
    const newChecked = e.target.checked;
    if (onChange) {
      onChange(newChecked);
    } else {
      setInternalChecked(newChecked);
    }
  };

  const containerStyles = {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacing.xs,
    fontFamily: tokens.typography.fontFamily,
  };

  const checkboxWrapperStyles = {
    display: 'flex',
    alignItems: 'center',
    gap: tokens.spacing.xs,
    cursor: disabled ? 'not-allowed' : 'pointer',
    userSelect: 'none',
  };

  const checkboxInputStyles = {
    appearance: 'none',
    width: '20px',
    height: '20px',
    border: `1.5px solid ${
      hasError
        ? tokens.colors.semantic.error
        : isChecked || indeterminate
        ? tokens.colors.primary[500]
        : tokens.colors.border.secondary
    }`,
    borderRadius: tokens.borderRadius.xs,
    backgroundColor: isChecked || indeterminate ? tokens.colors.primary[500] : tokens.colors.neutral[0],
    cursor: disabled ? 'not-allowed' : 'pointer',
    position: 'relative',
    transition: 'all 0.15s ease',
    flexShrink: 0,
    opacity: disabled ? 0.5 : 1,
  };

  const checkmarkStyles = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '12px',
    height: '12px',
    pointerEvents: 'none',
  };

  const labelStyles = {
    fontSize: tokens.typography.fontSize.md,
    color: disabled ? tokens.colors.content.tertiary : tokens.colors.content.primary,
    lineHeight: tokens.typography.lineHeight.normal,
  };

  const helperTextStyles = {
    fontSize: tokens.typography.fontSize.sm,
    color: hasError ? tokens.colors.semantic.error : tokens.colors.content.secondary,
    marginLeft: '28px',
  };

  return (
    <div style={containerStyles}>
      <label style={checkboxWrapperStyles}>
        <div style={{ position: 'relative' }}>
          <input
            type="checkbox"
            style={checkboxInputStyles}
            checked={isChecked}
            onChange={handleChange}
            disabled={disabled}
            aria-invalid={hasError}
            aria-describedby={error ? 'error-message' : helperText ? 'helper-text' : undefined}
          />
          {(isChecked || indeterminate) && (
            <svg
              style={checkmarkStyles}
              viewBox="0 0 12 12"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {indeterminate ? (
                <rect x="2" y="5" width="8" height="2" fill="white" />
              ) : (
                <path
                  d="M2 6L5 9L10 3"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}
            </svg>
          )}
        </div>
        {label && <span style={labelStyles}>{label}</span>}
      </label>

      {(error || helperText) && (
        <p
          id={error ? 'error-message' : 'helper-text'}
          style={helperTextStyles}
        >
          {error || helperText}
        </p>
      )}
    </div>
  );
};

// ==================== RADIO COMPONENT ====================
export const Radio = ({
  label,
  checked = false,
  onChange,
  disabled = false,
  name,
  value,
  error = '',
  helperText = '',
}) => {
  const hasError = !!error;

  const handleChange = (e) => {
    if (onChange) {
      onChange(e.target.value);
    }
  };

  const containerStyles = {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacing.xs,
    fontFamily: tokens.typography.fontFamily,
  };

  const radioWrapperStyles = {
    display: 'flex',
    alignItems: 'center',
    gap: tokens.spacing.xs,
    cursor: disabled ? 'not-allowed' : 'pointer',
    userSelect: 'none',
  };

  const radioInputStyles = {
    appearance: 'none',
    width: '20px',
    height: '20px',
    border: `1.5px solid ${
      hasError
        ? tokens.colors.semantic.error
        : checked
        ? tokens.colors.primary[500]
        : tokens.colors.border.secondary
    }`,
    borderRadius: '50%',
    backgroundColor: tokens.colors.neutral[0],
    cursor: disabled ? 'not-allowed' : 'pointer',
    position: 'relative',
    transition: 'all 0.15s ease',
    flexShrink: 0,
    opacity: disabled ? 0.5 : 1,
  };

  const dotStyles = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '10px',
    height: '10px',
    borderRadius: '50%',
    backgroundColor: tokens.colors.primary[500],
    pointerEvents: 'none',
  };

  const labelStyles = {
    fontSize: tokens.typography.fontSize.md,
    color: disabled ? tokens.colors.content.tertiary : tokens.colors.content.primary,
    lineHeight: tokens.typography.lineHeight.normal,
  };

  const helperTextStyles = {
    fontSize: tokens.typography.fontSize.sm,
    color: hasError ? tokens.colors.semantic.error : tokens.colors.content.secondary,
    marginLeft: '28px',
  };

  return (
    <div style={containerStyles}>
      <label style={radioWrapperStyles}>
        <div style={{ position: 'relative' }}>
          <input
            type="radio"
            style={radioInputStyles}
            checked={checked}
            onChange={handleChange}
            disabled={disabled}
            name={name}
            value={value}
            aria-invalid={hasError}
            aria-describedby={error ? 'error-message' : helperText ? 'helper-text' : undefined}
          />
          {checked && <div style={dotStyles} />}
        </div>
        {label && <span style={labelStyles}>{label}</span>}
      </label>

      {(error || helperText) && (
        <p
          id={error ? 'error-message' : 'helper-text'}
          style={helperTextStyles}
        >
          {error || helperText}
        </p>
      )}
    </div>
  );
};

// ==================== RADIO GROUP COMPONENT ====================
export const RadioGroup = ({
  label,
  options = [],
  value,
  onChange,
  disabled = false,
  error = '',
  helperText = '',
  name,
  direction = 'vertical', // 'vertical' or 'horizontal'
}) => {
  const [internalValue, setInternalValue] = useState(value);
  
  const currentValue = value !== undefined ? value : internalValue;
  const hasError = !!error;

  const handleChange = (newValue) => {
    if (onChange) {
      onChange(newValue);
    } else {
      setInternalValue(newValue);
    }
  };

  const containerStyles = {
    display: 'flex',
    flexDirection: 'column',
    gap: tokens.spacing.sm,
    fontFamily: tokens.typography.fontFamily,
  };

  const labelStyles = {
    fontSize: tokens.typography.fontSize.md,
    fontWeight: tokens.typography.fontWeight.medium,
    color: disabled ? tokens.colors.content.tertiary : tokens.colors.content.primary,
    lineHeight: tokens.typography.lineHeight.normal,
  };

  const optionsContainerStyles = {
    display: 'flex',
    flexDirection: direction === 'vertical' ? 'column' : 'row',
    gap: tokens.spacing.sm,
    flexWrap: direction === 'horizontal' ? 'wrap' : 'nowrap',
  };

  const helperTextStyles = {
    fontSize: tokens.typography.fontSize.sm,
    color: hasError ? tokens.colors.semantic.error : tokens.colors.content.secondary,
  };

  return (
    <div style={containerStyles}>
      {label && <label style={labelStyles}>{label}</label>}
      
      <div style={optionsContainerStyles} role="radiogroup" aria-invalid={hasError}>
        {options.map((option) => (
          <Radio
            key={option.value}
            label={option.label}
            value={option.value}
            checked={currentValue === option.value}
            onChange={handleChange}
            disabled={disabled || option.disabled}
            name={name}
          />
        ))}
      </div>

      {(error || helperText) && (
        <p
          id={error ? 'error-message' : 'helper-text'}
          style={helperTextStyles}
        >
          {error || helperText}
        </p>
      )}
    </div>
  );
};

// ==================== SWITCH COMPONENT ====================
export const Switch = ({
  label,
  checked = false,
  onChange,
  disabled = false,
  size = 'medium', // 'small', 'medium'
  labelPosition = 'right', // 'left', 'right'
}) => {
  const [internalChecked, setInternalChecked] = useState(checked);
  
  const isChecked = checked !== undefined ? checked : internalChecked;

  const handleChange = () => {
    if (disabled) return;
    
    const newChecked = !isChecked;
    if (onChange) {
      onChange(newChecked);
    } else {
      setInternalChecked(newChecked);
    }
  };

  const sizes = {
    small: {
      width: 36,
      height: 20,
      thumbSize: 16,
      thumbOffset: 2,
    },
    medium: {
      width: 44,
      height: 24,
      thumbSize: 20,
      thumbOffset: 2,
    },
  };

  const currentSize = sizes[size];

  const containerStyles = {
    display: 'flex',
    alignItems: 'center',
    gap: tokens.spacing.xs,
    flexDirection: labelPosition === 'left' ? 'row-reverse' : 'row',
    cursor: disabled ? 'not-allowed' : 'pointer',
    userSelect: 'none',
    fontFamily: tokens.typography.fontFamily,
  };

  const switchTrackStyles = {
    position: 'relative',
    width: `${currentSize.width}px`,
    height: `${currentSize.height}px`,
    backgroundColor: isChecked ? tokens.colors.primary[500] : tokens.colors.neutral[200],
    borderRadius: `${currentSize.height / 2}px`,
    transition: 'background-color 0.2s ease',
    opacity: disabled ? 0.5 : 1,
    flexShrink: 0,
  };

  const switchThumbStyles = {
    position: 'absolute',
    top: `${currentSize.thumbOffset}px`,
    left: isChecked
      ? `${currentSize.width - currentSize.thumbSize - currentSize.thumbOffset}px`
      : `${currentSize.thumbOffset}px`,
    width: `${currentSize.thumbSize}px`,
    height: `${currentSize.thumbSize}px`,
    backgroundColor: tokens.colors.neutral[0],
    borderRadius: '50%',
    transition: 'left 0.2s ease',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
  };

  const labelStyles = {
    fontSize: tokens.typography.fontSize.md,
    color: disabled ? tokens.colors.content.tertiary : tokens.colors.content.primary,
    lineHeight: tokens.typography.lineHeight.normal,
  };

  return (
    <label style={containerStyles} onClick={handleChange}>
      <div style={switchTrackStyles}>
        <div style={switchThumbStyles} />
      </div>
      {label && <span style={labelStyles}>{label}</span>}
    </label>
  );
};

// ==================== DEMO ====================
export default function FormComponentsDemo() {
  const [textareaValue, setTextareaValue] = useState('');
  const [checkbox1, setCheckbox1] = useState(false);
  const [checkbox2, setCheckbox2] = useState(true);
  const [checkboxIndeterminate, setCheckboxIndeterminate] = useState(false);
  const [radioValue, setRadioValue] = useState('option1');
  const [switch1, setSwitch1] = useState(false);
  const [switch2, setSwitch2] = useState(true);

  const containerStyle = {
    padding: '40px',
    backgroundColor: '#F9F9F9',
    minHeight: '100vh',
    fontFamily: tokens.typography.fontFamily,
  };

  const sectionStyle = {
    marginBottom: '48px',
    padding: '32px',
    backgroundColor: '#FFFFFF',
    borderRadius: '12px',
  };

  const titleStyle = {
    fontSize: '24px',
    fontWeight: 700,
    marginBottom: '24px',
    color: '#1A1A1A',
  };

  const subtitleStyle = {
    fontSize: '16px',
    fontWeight: 600,
    marginBottom: '16px',
    marginTop: '24px',
    color: '#393939',
  };

  const gridStyle = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
    gap: '24px',
    marginBottom: '24px',
  };

  return (
    <div style={containerStyle}>
      <div style={{ textAlign: 'center', marginBottom: '48px' }}>
        <h1 style={{ fontSize: '32px', fontWeight: 700, marginBottom: '8px', color: '#005A1A' }}>
          Portal Empresa - Design System
        </h1>
        <p style={{ fontSize: '16px', color: '#5E5E5E' }}>
          Textarea, Checkbox, Radio & Switch
        </p>
      </div>

      {/* TEXTAREA */}
      <div style={sectionStyle}>
        <h2 style={titleStyle}>📝 Textarea</h2>
        
        <h3 style={subtitleStyle}>Basic</h3>
        <div style={gridStyle}>
          <Textarea
            label="Comentário"
            placeholder="Digite seu comentário..."
            value={textareaValue}
            onChange={(e) => setTextareaValue(e.target.value)}
          />
          
          <Textarea
            label="Descrição"
            placeholder="Descreva o problema..."
            helperText="Máximo de 500 caracteres"
            maxLength={500}
            showCharCount
          />
        </div>

        <h3 style={subtitleStyle}>States</h3>
        <div style={gridStyle}>
          <Textarea
            label="Com Erro"
            placeholder="Digite algo..."
            error="Este campo é obrigatório"
          />
          
          <Textarea
            label="Desabilitado"
            placeholder="Campo desabilitado"
            value="Texto não editável"
            disabled
          />
        </div>

        <h3 style={subtitleStyle}>Resize Options</h3>
        <div style={gridStyle}>
          <Textarea
            label="Vertical Resize"
            placeholder="Redimensiona verticalmente..."
            resize="vertical"
          />
          
          <Textarea
            label="No Resize"
            placeholder="Sem redimensionar..."
            resize="none"
          />
        </div>
      </div>

      {/* CHECKBOX */}
      <div style={sectionStyle}>
        <h2 style={titleStyle}>✅ Checkbox</h2>
        
        <h3 style={subtitleStyle}>Basic</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Checkbox
            label="Aceito os termos e condições"
            checked={checkbox1}
            onChange={setCheckbox1}
          />
          
          <Checkbox
            label="Receber notificações por email"
            checked={checkbox2}
            onChange={setCheckbox2}
          />
          
          <Checkbox
            label="Indeterminate State"
            checked={false}
            indeterminate={true}
            helperText="Estado intermediário (alguns selecionados)"
          />
        </div>

        <h3 style={subtitleStyle}>States</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Checkbox
            label="Com erro"
            error="Você deve aceitar os termos"
          />
          
          <Checkbox
            label="Desabilitado (unchecked)"
            disabled
          />
          
          <Checkbox
            label="Desabilitado (checked)"
            checked
            disabled
          />
        </div>
      </div>

      {/* RADIO */}
      <div style={sectionStyle}>
        <h2 style={titleStyle}>🔘 Radio</h2>
        
        <h3 style={subtitleStyle}>Radio Group (Vertical)</h3>
        <RadioGroup
          label="Método de pagamento"
          name="payment"
          value={radioValue}
          onChange={setRadioValue}
          options={[
            { label: 'Cartão de crédito', value: 'credit' },
            { label: 'Cartão de débito', value: 'debit' },
            { label: 'PIX', value: 'pix' },
            { label: 'Boleto', value: 'boleto' },
          ]}
          helperText="Escolha uma forma de pagamento"
        />

        <h3 style={subtitleStyle}>Radio Group (Horizontal)</h3>
        <RadioGroup
          label="Tamanho"
          name="size"
          direction="horizontal"
          options={[
            { label: 'Pequeno', value: 'small' },
            { label: 'Médio', value: 'medium' },
            { label: 'Grande', value: 'large' },
          ]}
        />

        <h3 style={subtitleStyle}>With Error</h3>
        <RadioGroup
          label="Gênero"
          name="gender"
          error="Este campo é obrigatório"
          options={[
            { label: 'Masculino', value: 'male' },
            { label: 'Feminino', value: 'female' },
            { label: 'Outro', value: 'other' },
          ]}
        />
      </div>

      {/* SWITCH */}
      <div style={sectionStyle}>
        <h2 style={titleStyle}>🎚️ Switch</h2>
        
        <h3 style={subtitleStyle}>Basic</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Switch
            label="Ativar notificações"
            checked={switch1}
            onChange={setSwitch1}
          />
          
          <Switch
            label="Modo escuro"
            checked={switch2}
            onChange={setSwitch2}
          />
        </div>

        <h3 style={subtitleStyle}>Sizes</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Switch
            label="Small"
            size="small"
            checked={switch1}
            onChange={setSwitch1}
          />
          
          <Switch
            label="Medium (default)"
            size="medium"
            checked={switch2}
            onChange={setSwitch2}
          />
        </div>

        <h3 style={subtitleStyle}>Label Position</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Switch
            label="Label à direita (default)"
            labelPosition="right"
            checked={switch1}
            onChange={setSwitch1}
          />
          
          <Switch
            label="Label à esquerda"
            labelPosition="left"
            checked={switch2}
            onChange={setSwitch2}
          />
        </div>

        <h3 style={subtitleStyle}>States</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Switch
            label="Desabilitado (off)"
            disabled
          />
          
          <Switch
            label="Desabilitado (on)"
            checked
            disabled
          />
        </div>
      </div>
    </div>
  );
}
